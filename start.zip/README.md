# Projeto: Tasks CRUD (Django)

Projeto simples em Django para um CRUD de tarefas (tasks) usando SQLite.

## Histórias de usuário (mínimo 5)

1. Como usuário, quero ver a lista de tarefas para acompanhar minhas atividades.
2. Como usuário, quero criar novas tarefas com título, descrição e data de vencimento.
3. Como usuário, quero editar uma tarefa existente para atualizar informações.
4. Como usuário, quero marcar tarefas como concluídas para controlar progresso.
5. Como usuário, quero excluir tarefas que não são mais necessárias.

## Instalação e execução (Windows PowerShell)

```powershell
python -m pip install -r requirements.txt; 
python manage.py migrate; 
python manage.py runserver
```

Acesse `http://127.0.0.1:8000/` para usar o sistema de tasks.

## Observações
- Banco de dados padrão: SQLite (`db.sqlite3`).

## Deploy (produção) - notas rápidas

1. Variáveis de ambiente recomendadas:
	- `SECRET_KEY` (obrigatório em produção)
	- `DEBUG=False`
	- `ALLOWED_HOSTS` (ex.: `brenoharaujo2503.discloud.app`)

2. Instale dependências e gere arquivos estáticos:

```powershell
python -m pip install -r requirements.txt
python manage.py collectstatic --noinput
python manage.py migrate --noinput
```

3. Exemplo de comando para o host (Procfile já incluído):

```
web: gunicorn taskproj.wsgi:application --bind 0.0.0.0:$PORT --workers 3
```