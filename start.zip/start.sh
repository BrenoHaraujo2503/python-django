#!/bin/sh
set -e

# set defaults if not provided
: "${SECRET_KEY:=replace-this-with-a-secret-key}"
export SECRET_KEY

echo "Running migrations..."
python manage.py migrate --noinput || true

echo "Starting Gunicorn on 0.0.0.0:8080"
exec python -m gunicorn taskproj.wsgi:application --bind 0.0.0.0:8080 --workers 1 --timeout 120
