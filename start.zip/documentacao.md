# Documentação do projeto: python-crud (Tasks)

**Resumo**
- **Objetivo:** Aplicação Django simples para gerenciamento de tarefas (CRUD) com frontend renderizado e endpoints REST JSON.
- **Stack:** Python, Django 5.2.x, SQLite (local), Gunicorn (produção), WhiteNoise (servir estáticos). Projetos auxiliares: Dockerfile, `start.sh`, `Procfile`

**Estrutura do repositório (resumo)**
- `manage.py` : entrypoint do Django.
- `taskproj/` : pacote do projeto (settings, wsgi, urls).
- `tasks/` : app principal — modelos, views, templates, forms, urls, `api_views.py` (rotas JSON).
- `templates/` : templates HTML públicos.
- `static/` : CSS e assets públicos.
- `staticfiles/` : destino do `collectstatic` em produção.
- `db.sqlite3` : banco local (não versionar em produção).
- `requirements.txt` : dependências.
- `Dockerfile`, `start.sh`, `.dockerignore` : artefatos para containerização.

**Visão geral da aplicação**

O app `tasks` fornece as seguintes funcionalidades:
- Listar, criar, editar e excluir tarefas via frontend (templates Django).
- Endpoints JSON (simples) para integração via API (list/create, retrieve/update/delete, toggle completed).

-----------------------------
**Instalação (desenvolvimento)**

1. Recomendado criar e ativar um virtualenv:

```powershell
# Windows PowerShell
python -m venv .venv
.\\.venv\\Scripts\\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

2. Executar migrações e iniciar servidor de desenvolvimento:

```powershell
python manage.py migrate
python manage.py runserver 0.0.0.0:8000
```

3. Acesse `http://127.0.0.1:8000/` para ver a lista de tarefas.

-----------------------------
**Variáveis de ambiente e `taskproj/settings.py`**

As configurações importantes lidas em `settings.py`:
- `SECRET_KEY` — chave secreta do Django. Em produção NUNCA deixe embutida em código. Use variável de ambiente.
- `DEBUG` — use `DEBUG=True` apenas em dev; o settings lê `DEBUG` da env: `DEBUG='True'` ou `DEBUG='False'`.
- `ALLOWED_HOSTS` — atualmente contém `brenoharaujo2503.discloud.app`, `localhost`, `127.0.0.1`. Ajuste conforme domínio de produção.
- `CSRF_TRUSTED_ORIGINS` — lista separada por vírgula via env; necessário quando o app fica atrás de CDN/Proxy (ex: Cloudflare).
- `SECURE_SSL_REDIRECT` — por padrão `False` no settings para evitar loops; ative via env quando existir comunicação TLS direta.
- `SECURE_HSTS_SECONDS`, `SESSION_COOKIE_SECURE`, `CSRF_COOKIE_SECURE`, `USE_X_FORWARDED_HOST`, `SECURE_PROXY_SSL_HEADER` — usadas para hardening em produção.

Exemplo (Linux/PowerShell) para setar variáveis de ambiente antes de iniciar:

```powershell
# PowerShell (set temporário só para sessão)
$env:SECRET_KEY = 'coloque_uma_chave_segura_aqui'
$env:DEBUG = 'False'
$env:CSRF_TRUSTED_ORIGINS = 'https://seu-dominio.com'
$env:SECURE_SSL_REDIRECT = 'True'
# Em Linux export SECRET_KEY=...
```

-----------------------------
**Banco de dados**
- O projeto usa SQLite por padrão (`db.sqlite3`). Para produção considere usar PostgreSQL ou outro RDBMS.
- Comandos úteis:

```powershell
python manage.py makemigrations
python manage.py migrate
python manage.py showmigrations
```

-----------------------------
**Static files**
- WhiteNoise está configurado no `MIDDLEWARE` e `STATICFILES_STORAGE` para servir arquivos estáticos em produção.
- Antes de deployment, execute:

```powershell
python manage.py collectstatic --noinput
```

-----------------------------
**API: rotas JSON (simples)**

Os endpoints implementados em `tasks/api_views.py` e registrados em `tasks/urls.py`:

- `GET  /api/tasks/` — lista todas as tarefas (JSON array)
- `POST /api/tasks/` — cria uma nova tarefa (enviar JSON com campos do formulário: `title`, `description`, `due_date`, `completed` opcional)
- `GET  /api/tasks/<id>/` — retorna a tarefa
- `PUT|PATCH /api/tasks/<id>/` — atualiza a tarefa (JSON)
- `DELETE /api/tasks/<id>/` — remove a tarefa
- `POST /api/tasks/<id>/toggle/` — alterna o campo `completed` e retorna a tarefa atualizada

Exemplos (curl):

```bash
# Listar
curl -sS http://127.0.0.1:8000/api/tasks/

# Criar
curl -X POST -H "Content-Type: application/json" -d '{"title":"Comprar leite","description":"Lembrar de pegar leite","due_date":"2025-12-01"}' http://127.0.0.1:8000/api/tasks/

# Atualizar
curl -X PUT -H "Content-Type: application/json" -d '{"title":"Compras atualizada"}' http://127.0.0.1:8000/api/tasks/1/

# Alternar
curl -X POST http://127.0.0.1:8000/api/tasks/1/toggle/
```

Observação importante: as views de API atuais são marcadas com `@csrf_exempt` para simplicidade de teste. Em ambiente de produção deve-se proteger essas rotas com autenticação adequada (token/JWT/DRF) e remover `csrf_exempt`.

-----------------------------
**Frontend**
- Templates em `templates/` fornecem UI responsiva básica (lista de tarefas, formulário, confirmação de exclusão).
- Estilos principais em `static/css/style.css`.

-----------------------------
**Deployment (notas gerais e Discloud)**

Opções de deploy já preparadas no repositório:
- `Dockerfile` + `start.sh` — para executar migrations e iniciar `gunicorn` no container.
- `Procfile` — `web: gunicorn taskproj.wsgi:application --bind 0.0.0.0:$PORT --workers 3` (quando a plataforma usa `PORT` variável).
- `discloud.config` — arquivo experimentado durante implantação no Discloud (conteúdo tem sido iterado; recomenda-se configurar env vars no painel do provedor em vez de colocar segredos nesse arquivo).

Problemas comuns e soluções (apresentados durante desenvolvimento):
- 502 Bad Gateway / App não responde: verificar se o processo está escutando na porta esperada (ex.: 8080 ou $PORT). Use `python -m gunicorn taskproj.wsgi:application --bind 0.0.0.0:8080`.
- Processo iniciou `runserver` (127.0.0.1:8000) no ambiente de produção: isso ocorre quando a plataforma executa `manage.py runserver` automaticamente (verifique `MAIN` ou comando `START` na config). Garanta que `START` invoque `gunicorn` ou use `start.sh`.
- RuntimeError: "SECRET_KEY must be set in environment for production": configure `SECRET_KEY` via variáveis de ambiente antes de iniciar com `DEBUG=False`.
- ERR_TOO_MANY_REDIRECTS (redirect loop HTTPS): causado por `SECURE_SSL_REDIRECT=True` junto a TLS-terminating proxy (Cloudflare). Solução: habilitar `SECURE_PROXY_SSL_HEADER = ('HTTP_X_FORWARDED_PROTO','https')` e `USE_X_FORWARDED_HOST = True`, ou desabilitar `SECURE_SSL_REDIRECT` e deixar o proxy lidar com HTTPS.
- 403 CSRF: quando por trás de CDN/proxy inclua a origem em `CSRF_TRUSTED_ORIGINS` (com esquema `https://example.com`) e assegure `CSRF_COOKIE_SECURE=True` em produção.

Checklist de deploy seguro
- [ ] Remover `DEBUG=True` em produção
- [ ] Definir `SECRET_KEY` via variável de ambiente
- [ ] Ajustar `ALLOWED_HOSTS` para domínios reais
- [ ] Habilitar `SECURE_SSL_REDIRECT` somente se a comunicação entre o proxy e app for TLS
- [ ] Gerenciar `CSRF_TRUSTED_ORIGINS` corretamente
- [ ] Usar banco de dados robusto (Postgres) em produção
- [ ] Monitoramento e logs (stdout/stderr do gunicorn) configurados

-----------------------------
**Anexo: Resumo das rotas importantes**
- Frontend:
  - `/` — lista de tarefas (HTML)
  - `/create/` — formulário criar
  - `/<id>/edit/` — editar
  - `/<id>/delete/` — confirmar exclusão
